---
name: Kinetic Precision
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8c909f'
  outline-variant: '#424654'
  surface-tint: '#b0c6ff'
  primary: '#b0c6ff'
  on-primary: '#002c6f'
  primary-container: '#0b5ed7'
  on-primary-container: '#dae2ff'
  inverse-primary: '#0057cc'
  secondary: '#f0c12c'
  on-secondary: '#3d2e00'
  secondary-container: '#d2a501'
  on-secondary-container: '#503d00'
  tertiary: '#c8c6c5'
  on-tertiary: '#303030'
  tertiary-container: '#666565'
  on-tertiary-container: '#e6e3e2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00419d'
  secondary-fixed: '#ffdf90'
  secondary-fixed-dim: '#f0c12c'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1b1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Montserrat
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  headline-xl-mobile:
    fontFamily: Montserrat
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

The design system is engineered to evoke the high-performance atmosphere of a professional automotive workshop. It balances industrial strength with digital sophistication, targeting car enthusiasts and premium vehicle owners who value technical expertise and precision.

The visual direction is **Corporate / Modern** with a **High-Tech** edge. It utilizes a dark-mode foundation to simulate a sleek showroom environment, punctuated by vibrant technical accents. The interface feels fast, reliable, and cutting-edge through the use of:
- **Minimalism:** Lean layouts that prioritize data and service clarity.
- **Glassmorphism:** Subtle translucent layers for secondary information to maintain depth without clutter.
- **High-Contrast Accents:** Strategic use of Golden Yellow to guide the eye toward critical diagnostic and conversion points.

## Colors

The palette is anchored in a deep "Garage Black" to provide a high-contrast canvas for technical data. 

- **Primary (Electric Blue):** Used for primary brand elements, active states, and structural highlights. It conveys trust and advanced technology.
- **Accent (Golden Yellow):** Reserved strictly for high-priority Call-to-Actions (CTAs), warnings, or critical service alerts. This color demands attention against the dark background.
- **Backgrounds:** A tiered system of `#0D0D0D` for global canvas areas and `#1E1E1E` for elevated cards and sections.
- **Surfaces:** Neutral grays bridge the gap between deep backgrounds and white text, used primarily for borders, disabled states, and secondary labels.

## Typography

The system utilizes **Montserrat** (substituted for Poppins for a more geometric, automotive-industrial feel) for headings to provide a bold, authoritative presence. **Inter** is used for all functional and body text to ensure maximum legibility at various weights.

- **Headlines:** Should always be high-contrast (White) and often use tighter letter spacing for a "mechanical" look.
- **Body:** Uses a slightly larger base size (16px) to ensure readability in high-glare environments (like a workshop tablet).
- **Labels:** Small caps and bold weights are used for technical specifications and data headers to mimic automotive technical manuals.

## Layout & Spacing

The layout follows a **Fluid Grid** model based on a 12-column system. 

- **Desktop:** 12 columns with 24px gutters. Content is centered with a max-width of 1440px.
- **Tablet:** 8 columns with 16px gutters.
- **Mobile:** 4 columns with 16px margins. 

Spacing follows a strict 8px rhythm to maintain technical alignment. Heavy use of whitespace between sections is encouraged to emphasize a "premium" feel and prevent the UI from feeling "greasy" or cluttered.

## Elevation & Depth

Hierarchy is established using **Tonal Layers** and **Subtle Glassmorphism**.

1.  **Level 0 (Canvas):** Deep Black (`#0D0D0D`).
2.  **Level 1 (Cards/Sections):** Dark Gray (`#1E1E1E`). Features a 1px border of `rgba(255, 255, 255, 0.05)` to define edges against the canvas.
3.  **Level 2 (Overlays/Glass):** Translucent background blurs (12px-20px blur) with a 10% white tint. This is used for navigation bars and sticky headers.

**Shadows:** Shadows are rarely used for depth; instead, luminosity is the primary driver. Where used (e.g., on hover for service cards), use a soft Blue or Gold glow: `0px 10px 30px rgba(11, 94, 215, 0.2)`.

## Shapes

The system uses a **Rounded** language to soften the aggressive color palette and create a modern, approachable feel. 

- **Base Radius (8px):** Standard for inputs and small components.
- **Large Radius (16px):** Primary for service cards and modal containers.
- **Full Radius (Pill):** Used exclusively for chips, tags, and specific toggle switches to differentiate them from actionable buttons.

## Components

### Buttons
- **Primary:** Electric Blue background, white text. Transitions to a slightly lighter blue on hover.
- **CTA (Golden):** Golden Yellow background, Deep Black text. This is reserved for "Book Service" or "Get Quote."
- **Ghost:** Transparent background with a 1px Electric Blue border.

### Service Cards
Cards should feature a subtle hover effect that shifts the background from `#1E1E1E` to a slightly lighter gray, accompanied by a primary blue top-border (3px) to indicate focus. Use glassmorphism for info-overlays on car images.

### Input Fields
Inputs use a dark fill (`#0D0D0D`) with a Medium Gray border. On focus, the border shifts to Electric Blue with a soft 2px outer glow.

### Icons
Use a custom set of geometric, thin-stroke (2px) icons. All automotive icons (engine, battery, oil) should use the Electric Blue stroke, while warning icons should utilize the Golden Yellow.

### Chips & Status
- **Status Indicators:** Use pill-shaped containers. "Completed" (Green), "In Progress" (Blue), "Pending" (Yellow).